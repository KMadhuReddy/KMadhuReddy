package com.madhu.demo.service;
import org.springframework.data.jpa.repository.JpaRepository;

import com.madhu.demo.model.*;

	public interface PersonRepository extends JpaRepository<Person, Integer>
	{

	}