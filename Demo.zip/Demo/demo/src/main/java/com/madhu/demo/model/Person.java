package com.madhu.demo.model;

public class Person {
	private int Personid;
	private String Name;
	private int Age;

	public int getPersonid() {
		return Personid;
	}

	public void setPersonid(int personid) {
		Personid = personid;
	}

	public String getName() {
		return Name;
	}

	public void setName(String name) {
		this.Name = name;
	}

	public int getAge() {
		return Age;
	}

	public void setAge(int age) {
		Age = age;
	}

	

	@Override
	public String toString() {
		return "Person [Personid=" + Personid + ", name=" + Name + ", Age=" + Age + "]";
	}

	public Person(int personid, String name, int age) {
		super();
		Personid = personid;
		this.Name = name;
		Age = age;
	}

}