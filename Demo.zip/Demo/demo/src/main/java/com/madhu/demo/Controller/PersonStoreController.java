package com.madhu.demo.Controller;

import java.util.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.madhu.demo.model.Person;
import com.madhu.demo.service.PersonService;

@RestController
public class PersonStoreController {
	@Autowired
	private PersonService Personservice;

	@GetMapping("/Persons")
	public List<Person> getAllPerson() {
		List<Person> allPersonList = Personservice.getAllPerson();
		return allPersonList;
	}

	@GetMapping("/Persons/{Personid}")
	public Person getPersonById(@PathVariable String Personid) {
		Person PersonDetails = Personservice.getPersonById(Integer.parseInt(Personid));
//		if(PersonDetails==null)  
//			throw new UserNotFoundException("id: "+ Personid);  
		return PersonDetails;
	}
	
	@GetMapping("/Persons/Name/{Name}")
	public Person getPersonByName(@PathVariable String Name) {
		Person PersonDetails = Personservice.getPersonByName(Name);
		return PersonDetails;
	}
	
	@GetMapping("/Persons/Age/{Age}")
	public Person getPersonByAge(@PathVariable String Age) {
		Person PersonDetails = Personservice.getPersonByAge(Integer.parseInt(Age));
		return PersonDetails;
	}

	@RequestMapping(method = RequestMethod.POST, value = "/Persons")
	public void addPerson(@RequestBody Person Person) {
		Personservice.addPerson(Person);
	}

	@RequestMapping(method = RequestMethod.PUT, value = "/Persons/{Personid}")
	public void editPerson(@RequestBody Person Person, @PathVariable String Personid) {
		Personservice.editPerson(Person, Integer.parseInt(Personid));
	}

	@RequestMapping(method = RequestMethod.DELETE, value = "/Persons/{Personid}")
	public void deletePerson(@RequestBody Person Person, @PathVariable String Personid) {
		Personservice.deletePerson(Integer.parseInt(Personid));
	}

}