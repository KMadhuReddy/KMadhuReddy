package com.madhu.demo.service;

import java.util.*;
import com.madhu.demo.model.Person;
import org.springframework.stereotype.Component;
@Component
public class PersonService implements IPersonService
{
	private static List<Person> Persons = new ArrayList<Person>();
	static
	{
	Person Person1=new Person(1,"Madhu",30);
	Person Person2=new Person(2,"Prabhanshu",60);
	Person Person3=new Person(3,"Nayak",70);
	Persons.add(Person1);
	Persons.add(Person2);
	Persons.add(Person3);
		}
	public void addPerson(Person Person)
	{
	Persons.add(Person);	 
		}

	public void editPerson(Person Person, int Personid) 
	{
	Person record=getPersonById(Personid); 
		Persons.remove(record);
		Person.setPersonid(Personid);
		Persons.add(Person);
	}

	public boolean deletePerson(int Personid) {
	 Person record =getPersonById(Personid);
	 Persons.remove(record);
		return Boolean.TRUE;
	}

	public Person getPersonById(int Personid) 
	{
			return Persons.stream().filter(b ->b.getPersonid() == Personid).findFirst().get();
	}
	
	public Person getPersonByName(String Name) 
	{
			return Persons.stream().filter(b ->b.getName() == Name).findFirst().get();
	}
	
	public Person getPersonByAge(int Age) 
	{
			return Persons.stream().filter(b ->b.getAge() == Age).findFirst().get();
	}

	public List<Person> getAllPerson()
	{
		return Persons;
	}

}